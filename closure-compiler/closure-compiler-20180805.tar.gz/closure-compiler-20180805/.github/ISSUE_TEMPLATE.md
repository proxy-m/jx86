<!--
If you are asking a question - rather than filing a bug, try one of these instead:

- StackOverflow (http://stackoverflow.com/questions/tagged/google-closure-compiler)
- Mailing List (https://groups.google.com/forum/#!forum/closure-compiler-discuss)
-->

<!-- Make sure you list the relevant compiler flags or options used -->
