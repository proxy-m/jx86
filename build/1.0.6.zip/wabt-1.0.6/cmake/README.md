FindRE2C.cmake is copied from the [CMakeXFind
repository](https://github.com/julp/CMakeXFind). This makes it more convenient
to build for users who can't/won't run `git submodule update --init`.
